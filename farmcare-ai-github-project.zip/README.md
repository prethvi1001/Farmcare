# 🐄 FarmCare AI — Smart Livestock Management
### ஸ்மார்ட் கால்நடை மேலாண்மை

A mobile-first, bilingual (Tamil / English) web app that helps farmers manage livestock health: photo and voice health checks, first aid, vaccination guidance, feed planning, animal records and quick access to veterinary help.

**Animals:** 🐄 Cow / மாடு · 🐐 Goat / ஆடு · 🐑 Sheep / செம்மறியாடு · 🐔 Hen / கோழி

## Features

| Feature | What it does |
|---|---|
| Mobile OTP login | Mobile number + OTP (demo), or continue as guest |
| Tamil / English | Switch language on the login screen |
| Photo + voice scan | Upload a photo, speak or type symptoms, get possible causes and a risk level |
| Voice AI | Ask in Tamil or English and listen to the answer |
| First Aid Library | Snake bite, pregnancy care, bloat/stomach upset, wounds, heat stress, diarrhea and more, per animal |
| Vaccination guide | Vaccine name, disease prevented, season, dose volume and deworming, per animal |
| Feed management | Daily kg of green fodder, dry fodder, concentrate, minerals and water, per animal |
| Livestock records | Animal profiles with vaccination history (saved between visits) |
| Reminders | Due-soon and overdue vaccinations |
| Nearby vet / Emergency | Location-based help screens (sample data) |

## Project structure

```
farmcare-ai/
├── index.html              Page shell; loads the CSS and scripts below
├── css/
│   └── styles.css          All styling
├── js/
│   ├── config.js           App state, constants, animal types
│   ├── storage.js          Save / load animal records
│   ├── utils.js            Ids, dates, navigation, bilingual labels, speech
│   ├── data/               Content only (easy to edit)
│   │   ├── ai-engine.js          Symptom analysis, risk-level first aid, voice replies
│   │   ├── first-aid-topics.js   First Aid Library
│   │   ├── vaccination-guide.js  Vaccines, seasons, doses, deworming
│   │   ├── feed-guide.js         Daily feed and water quantities
│   │   └── vets.js               Sample vet directory (demo)
│   ├── views/              One file per screen
│   │   ├── core.js  auth.js  home.js  scan.js  first-aid.js  vets.js
│   │   └── vaccination.js  records.js  feed.js  reminders.js  voice.js  settings.js
│   ├── handlers.js         Click and form handlers
│   └── main.js             Start-up
├── assets/
│   ├── images/bull-logo.png    App logo shown on splash and login
│   └── branding/               Extra logo files (SVG / PNG)
├── .nojekyll
└── .gitignore
```

Plain HTML, CSS and JavaScript: no build step and no dependencies. Scripts are loaded in the order listed in `index.html` (each file relies on the ones above it).

## Run locally

Open `index.html` in a browser. To serve it instead: `python3 -m http.server` and visit `http://localhost:8000`.

**Demo login:** mobile `9876543210`, OTP `1234` (any 10-digit number works; the OTP is shown on screen), or tap *Continue as Guest*.

## Deploy with GitHub Pages

1. Create a repository (e.g. `farmcare-ai`) and upload everything in this folder to the repository root, keeping the folders.
2. **Settings → Pages**, Source: branch `main`, folder `/ (root)`, then Save.
3. After about a minute the site is live at `https://<your-username>.github.io/farmcare-ai/`.

## Editing content

- Vaccines, seasons and doses: `js/data/vaccination-guide.js`
- First aid steps: `js/data/first-aid-topics.js`
- Feed quantities: `js/data/feed-guide.js`
- Colours and layout: `css/styles.css`

## Important notice

This app does **not** diagnose disease and does not replace professional veterinary care. Photo and symptom analysis only suggests *possible* causes. It does not prescribe medicines or dosages. Vaccination schedules, doses and feed quantities are general reference guidance that vary by region, breed, age, weight and health; confirm with a licensed veterinarian or animal husbandry officer. In an emergency, get professional veterinary help immediately. The nearby-vet list is sample data and must be connected to a verified directory before real use.

## Logo

If the bull logo was sourced from a third party, confirm you have the right to use it before publishing publicly.
