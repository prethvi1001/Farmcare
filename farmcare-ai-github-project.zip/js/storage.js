/* FarmCare AI — Saving and loading animal records (persistent storage) */
"use strict";


/* ---------------- Storage helpers ---------------- */
async function loadAnimals(){
  try{
    const listing = await window.storage.list('animal:');
    const keys = (listing && listing.keys) || [];
    const animals = [];
    for(const k of keys){
      try{
        const r = await window.storage.get(k);
        if(r && r.value) animals.push(JSON.parse(r.value));
      }catch(e){}
    }
    animals.sort((a,b)=> (b.createdAt||0)-(a.createdAt||0));
    state.animals = animals;
  }catch(e){ console.error('load animals failed', e); }
}

async function saveAnimal(animal){
  try{
    await window.storage.set('animal:'+animal.id, JSON.stringify(animal));
  }catch(e){ console.error('save failed', e); }
}

async function deleteAnimal(id){
  try{ await window.storage.delete('animal:'+id); }catch(e){}
  state.animals = state.animals.filter(a=>a.id!==id);
  render();
}

function getAnimal(id){ return state.animals.find(a=>a.id===id); }
