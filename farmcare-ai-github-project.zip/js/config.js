/* FarmCare AI — App state, constants and animal types */
"use strict";


/* ---------------- State ---------------- */
const state = {
  page: 'splash',
  prevPage: 'home',
  auth: { step:'mobile', mobile:'', otp:'', generatedOtp:'', error:'' },
  lang: 'both',
  animalTypeFilter: 'cow',
  firstAid: { animalType:'cow', topicId:null },
  vaccGuideAnimal: 'cow',
  scan: { animalType:'cow', photoData:null, symptomsText:'', result:null, listening:false },
  selectedAnimalId: null,
  voice: { listening:false, transcript:'', reply:null },
  liveShare: { active:false, vetName:null },
  animals: [],
  farmerName:'Farmer',
};


const ANIMAL_TYPES = [
  {id:'cow', ic:'🐄', en:'Cow', ta:'மாடு'},
  {id:'goat', ic:'🐐', en:'Goat', ta:'ஆடு'},
  {id:'sheep', ic:'🐑', en:'Sheep', ta:'செம்மறியாடு'},
  {id:'hen', ic:'🐔', en:'Hen', ta:'கோழி'},
];


const DEMO_CREDENTIALS = { mobile: '9876543210', otp: '1234' };

const LOGO_IMG_DATA = "assets/images/bull-logo.png";


function animalMeta(id){ return ANIMAL_TYPES.find(a=>a.id===id) || ANIMAL_TYPES[0]; }
