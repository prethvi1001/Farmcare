/* FarmCare AI — App start-up: load saved animals, show splash, move to login */
"use strict";


/* ---------------- Init ---------------- */
loadAnimals().finally(()=>{
  render();
  setTimeout(()=>{
    if(state.page === 'splash'){ go('login'); }
  }, 1800);
});
