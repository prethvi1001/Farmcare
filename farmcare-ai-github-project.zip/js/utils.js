/* FarmCare AI — Small helpers: ids, dates, navigation, bilingual labels, speech */
"use strict";


function uid(prefix){ return prefix+'_'+Date.now().toString(36)+Math.random().toString(36).slice(2,7); }


function todayISO(){ return new Date().toISOString().slice(0,10); }

function daysBetween(a,b){ return Math.round((new Date(b)-new Date(a))/86400000); }

function vaccStatus(nextDue){
  if(!nextDue) return 'due';
  const d = daysBetween(todayISO(), nextDue);
  if(d < 0) return 'overdue';
  if(d <= 14) return 'due';
  return 'completed'; // far away = on schedule; treat as "completed/scheduled"
}

function fmtDate(d){
  if(!d) return '—';
  try{ return new Date(d+'T00:00:00').toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'}); }catch(e){ return d; }
}


/* ---------------- Navigation ---------------- */
function go(page, extra){
  state.prevPage = state.page;
  state.page = page;
  if(extra) Object.assign(state, extra);
  render();
  const scr = document.querySelector('.screen');
  if(scr) scr.scrollTop = 0;
}


/* ---------------- Bilingual helper ---------------- */
function bi(en, ta, inline){
  return `<span class="bi${inline?' inline':''}"><span class="en">${en}</span><span class="ta">${ta}</span></span>`;
}


/* ---------------- Speech helpers ---------------- */
function speechLangCode(){ return state.lang === 'en' ? 'en-IN' : 'ta-IN'; }

function speak(text, lang){
  try{
    if(!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = lang || 'ta-IN';
    u.rate = 0.95;
    window.speechSynthesis.speak(u);
  }catch(e){ console.error(e); }
}

function getRecognition(lang){
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if(!SR) return null;
  const r = new SR();
  r.lang = lang;
  r.interimResults = false;
  r.maxAlternatives = 1;
  return r;
}
