/* FarmCare AI — Vaccination and deworming reference guide (per animal) */
"use strict";


/* ---------------- Vaccination & Deworming Guide (general reference, per animal) ---------------- */
const VACCINATION_GUIDE = {
  cow:{
    intro:{en:'Vaccination protects a healthy animal from specific diseases in advance. Deworming removes internal parasites (worms) that are already present. Both are needed — one does not replace the other.',
           ta:'தடுப்பூசி என்பது ஆரோக்கியமான விலங்குக்கு குறிப்பிட்ட நோய்கள் வராமல் முன்கூட்டியே பாதுகாப்பது. வார்ம் நீக்கம் (Deworming) என்பது ஏற்கனவே உள்ள உள் ஒட்டுண்ணிகளை (புழுக்கள்) நீக்குவது. இரண்டும் தேவை — ஒன்று மற்றொன்றுக்கு மாற்று அல்ல.'},
    vaccines:[
      {name_en:'FMD (Foot & Mouth Disease) vaccine', name_ta:'கால்வாய் நோய் தடுப்பூசி (FMD)', prevents_en:'Foot and Mouth Disease', prevents_ta:'கால்வாய் நோய்', season_en:'Twice a year — before monsoon (May–June) and before winter (Oct–Nov)', season_ta:'ஆண்டுக்கு இரு முறை — மழைக்காலத்திற்கு முன் (மே–ஜூன்) மற்றும் குளிர்காலத்திற்கு முன் (அக்–நவ)', dose_en:'≈ 3 ml, intramuscular (typical adult dose)', dose_ta:'≈ 3 ml, தசைக்குள் ஊசி (பொது வயது வந்த மாட்டு அளவு)'},
      {name_en:'HS (Haemorrhagic Septicaemia) vaccine', name_ta:'இரத்தக்கசிவு தொற்று தடுப்பூசி (HS)', prevents_en:'Haemorrhagic Septicaemia', prevents_ta:'இரத்தக்கசிவு தொற்று நோய்', season_en:'Once a year, before monsoon (May–June)', season_ta:'ஆண்டுக்கு ஒரு முறை, மழைக்காலத்திற்கு முன் (மே–ஜூன்)', dose_en:'≈ 5 ml, subcutaneous', dose_ta:'≈ 5 ml, தோலின் அடியில் ஊசி'},
      {name_en:'BQ (Black Quarter) vaccine', name_ta:'கறுப்பு தொடை நோய் தடுப்பூசி (BQ)', prevents_en:'Black Quarter disease', prevents_ta:'கறுப்பு தொடை நோய்', season_en:'Once a year, before monsoon', season_ta:'ஆண்டுக்கு ஒரு முறை, மழைக்காலத்திற்கு முன்', dose_en:'≈ 5 ml, subcutaneous', dose_ta:'≈ 5 ml, தோலின் அடியில் ஊசி'},
      {name_en:'Brucellosis vaccine (calves)', name_ta:'பிரூசெல்லோசிஸ் தடுப்பூசி (கன்றுகள்)', prevents_en:'Brucellosis', prevents_ta:'பிரூசெல்லோசிஸ்', season_en:'One-time, at 4–8 months of age (female calves)', season_ta:'ஒரு முறை மட்டும், 4–8 மாத வயதில் (பெண் கன்றுகள்)', dose_en:'As per vet (single fixed dose vaccine)', dose_ta:'மருத்துவர் அளவீட்டின்படி (ஒரு நிலையான அளவு தடுப்பூசி)'},
    ],
    deworming:{en:'Deworm every 3 months (every 90 days); calves may need it more often (every 1–2 months) as advised by a vet. Deworm again 2 weeks after heavy rain/flood-prone periods.', ta:'ஒவ்வொரு 3 மாதங்களுக்கும் (90 நாட்களுக்கும்) ஒரு முறை வார்ம் நீக்கம் செய்யவும்; கன்றுகளுக்கு மருத்துவர் ஆலோசனையின்படி 1–2 மாதங்களுக்கு ஒரு முறை தேவைப்படலாம். அதிக மழை/வெள்ள காலத்திற்கு 2 வாரங்களுக்குப் பிறகு மீண்டும் செய்யவும்.'},
  },
  goat:{
    intro:{en:'Vaccination prevents specific diseases before they occur; deworming clears existing internal parasites. Goats need both on a regular schedule because they are especially prone to worm load.',
           ta:'தடுப்பூசி நோய்கள் வராமல் முன்கூட்டியே தடுக்கும்; வார்ம் நீக்கம் ஏற்கனவே உள்ள புழுக்களை நீக்கும். ஆடுகளுக்கு புழு பாதிப்பு அதிகமாக இருப்பதால் இரண்டும் தொடர்ந்து தேவை.'},
    vaccines:[
      {name_en:'PPR (Peste des Petits Ruminants) vaccine', name_ta:'PPR தடுப்பூசி', prevents_en:'PPR (a serious viral disease of goats/sheep)', prevents_ta:'PPR (ஆடு/செம்மறியாட்டின் தீவிர வைரஸ் நோய்)', season_en:'Once a year, before monsoon', season_ta:'ஆண்டுக்கு ஒரு முறை, மழைக்காலத்திற்கு முன்', dose_en:'≈ 1 ml, subcutaneous', dose_ta:'≈ 1 ml, தோலின் அடியில் ஊசி'},
      {name_en:'Enterotoxaemia (ET) vaccine', name_ta:'என்டெரோடாக்ஸீமியா தடுப்பூசி (ET)', prevents_en:'Enterotoxaemia ("overeating disease")', prevents_ta:'என்டெரோடாக்ஸீமியா ("அதிக தீவனம் நோய்")', season_en:'Once a year, before monsoon / before lush green fodder season', season_ta:'ஆண்டுக்கு ஒரு முறை, மழைக்காலத்திற்கு முன் / பசுந்தீவனம் அதிகமாகும் காலத்திற்கு முன்', dose_en:'≈ 1–2 ml, subcutaneous', dose_ta:'≈ 1–2 ml, தோலின் அடியில் ஊசி'},
      {name_en:'FMD vaccine', name_ta:'கால்வாய் நோய் தடுப்பூசி (FMD)', prevents_en:'Foot and Mouth Disease', prevents_ta:'கால்வாய் நோய்', season_en:'Twice a year, before monsoon and before winter', season_ta:'ஆண்டுக்கு இரு முறை, மழைக்காலத்திற்கு முன் மற்றும் குளிர்காலத்திற்கு முன்', dose_en:'≈ 1–2 ml (smaller than cattle dose)', dose_ta:'≈ 1–2 ml (மாட்டைக் காட்டிலும் குறைவு)'},
    ],
    deworming:{en:'Deworm every 3 months; kids (young goats) may need deworming every month for the first few months, as advised by a vet.', ta:'ஒவ்வொரு 3 மாதங்களுக்கும் வார்ம் நீக்கம் செய்யவும்; குட்டிகளுக்கு முதல் சில மாதங்களில் மருத்துவர் ஆலோசனையின்படி மாதம் ஒரு முறை தேவைப்படலாம்.'},
  },
  sheep:{
    intro:{en:'Vaccination protects against specific diseases before infection; deworming clears existing worm load. Sheep kept on pasture need frequent deworming.',
           ta:'தடுப்பூசி தொற்று வருவதற்கு முன்பே தடுக்கும்; வார்ம் நீக்கம் ஏற்கனவே உள்ள புழுக்களை நீக்கும். மேய்ச்சலில் இருக்கும் செம்மறியாடுகளுக்கு அடிக்கடி வார்ம் நீக்கம் தேவை.'},
    vaccines:[
      {name_en:'PPR vaccine', name_ta:'PPR தடுப்பூசி', prevents_en:'PPR (serious viral disease)', prevents_ta:'PPR (தீவிர வைரஸ் நோய்)', season_en:'Once a year, before monsoon', season_ta:'ஆண்டுக்கு ஒரு முறை, மழைக்காலத்திற்கு முன்', dose_en:'≈ 1 ml, subcutaneous', dose_ta:'≈ 1 ml, தோலின் அடியில் ஊசி'},
      {name_en:'Sheep Pox vaccine', name_ta:'செம்மறியாடு பாக்ஸ் தடுப்பூசி', prevents_en:'Sheep Pox', prevents_ta:'செம்மறியாடு பாக்ஸ் நோய்', season_en:'Once a year, before summer', season_ta:'ஆண்டுக்கு ஒரு முறை, கோடைக்காலத்திற்கு முன்', dose_en:'≈ 0.5–1 ml as per vaccine label', dose_ta:'≈ 0.5–1 ml, தடுப்பூசி லேபிளின்படி'},
      {name_en:'Enterotoxaemia (ET) vaccine', name_ta:'என்டெரோடாக்ஸீமியா தடுப்பூசி', prevents_en:'Enterotoxaemia', prevents_ta:'என்டெரோடாக்ஸீமியா', season_en:'Once a year, before lush fodder season', season_ta:'ஆண்டுக்கு ஒரு முறை, பசுந்தீவன காலத்திற்கு முன்', dose_en:'≈ 1–2 ml, subcutaneous', dose_ta:'≈ 1–2 ml, தோலின் அடியில் ஊசி'},
      {name_en:'FMD vaccine', name_ta:'கால்வாய் நோய் தடுப்பூசி', prevents_en:'Foot and Mouth Disease', prevents_ta:'கால்வாய் நோய்', season_en:'Twice a year', season_ta:'ஆண்டுக்கு இரு முறை', dose_en:'≈ 1–2 ml', dose_ta:'≈ 1–2 ml'},
    ],
    deworming:{en:'Deworm every 3 months; more frequently for lambs and flocks grazing on shared pasture, as advised by a vet.', ta:'ஒவ்வொரு 3 மாதங்களுக்கும் வார்ம் நீக்கம் செய்யவும்; குட்டிகளுக்கும் பொது மேய்ச்சல் நிலத்தில் உள்ளவைகளுக்கும் அடிக்கடி தேவைப்படலாம்.'},
  },
  hen:{
    intro:{en:'Poultry vaccination schedules are given very early in life (starting day 1) and are usually done by dropper/eye-drop or injection at the hatchery or in the first few weeks. Deworming for internal parasites is done periodically as advised, especially in birds kept on open ground.',
           ta:'கோழிகளுக்கான தடுப்பூசி அட்டவணை மிக இளம் வயதிலேயே (முதல் நாளிலிருந்தே) தொடங்கும், பொதுவாக டிராப்பர்/கண் சொட்டு அல்லது ஊசி மூலம் ஹேட்சரியில் அல்லது முதல் சில வாரங்களில் கொடுக்கப்படும். வெளியில் வளர்க்கும் கோழிகளுக்கு உள் ஒட்டுண்ணி நீக்கம் அவ்வப்போது தேவை.'},
    vaccines:[
      {name_en:"Marek's Disease vaccine", name_ta:'மரேக்ஸ் நோய் தடுப்பூசி', prevents_en:"Marek's Disease", prevents_ta:'மரேக்ஸ் நோய்', season_en:'Day 1 (at hatchery)', season_ta:'1வது நாள் (ஹேட்சரியில்)', dose_en:'0.2 ml, subcutaneous (hatchery-administered)', dose_ta:'0.2 ml, தோலின் அடியில் (ஹேட்சரியில் கொடுக்கப்படும்)'},
      {name_en:'Newcastle (Ranikhet) F1 vaccine', name_ta:'ராணிகேட் நோய் F1 தடுப்பூசி', prevents_en:'Newcastle / Ranikhet Disease', prevents_ta:'ராணிகேட் நோய்', season_en:'Day 5–7, eye drop', season_ta:'5–7 நாட்கள், கண் சொட்டு', dose_en:'1 drop in the eye', dose_ta:'கண்ணில் 1 சொட்டு'},
      {name_en:'IBD (Gumboro) vaccine', name_ta:'IBD (கம்போரோ) தடுப்பூசி', prevents_en:'Infectious Bursal Disease (Gumboro)', prevents_ta:'இன்ஃபெக்ஷியஸ் பர்சல் நோய் (கம்போரோ)', season_en:'Day 14–21, drinking water or eye drop', season_ta:'14–21 நாட்கள், குடிநீர் அல்லது கண் சொட்டு', dose_en:'As per vaccine label', dose_ta:'தடுப்பூசி லேபிளின்படி'},
      {name_en:'Newcastle R2B/Lasota booster', name_ta:'ராணிகேட் R2B/லசோட்டா ஊக்கூசி', prevents_en:'Newcastle Disease (booster)', prevents_ta:'ராணிகேட் நோய் (ஊக்கூசி)', season_en:'6–8 weeks', season_ta:'6–8 வாரங்கள்', dose_en:'As per vaccine label, drinking water or eye drop', dose_ta:'தடுப்பூசி லேபிளின்படி, குடிநீர் அல்லது கண் சொட்டு'},
      {name_en:'Fowl Pox vaccine', name_ta:'கோழி பாக்ஸ் தடுப்பூசி', prevents_en:'Fowl Pox', prevents_ta:'கோழி பாக்ஸ் நோய்', season_en:'6–8 weeks, wing-web stab', season_ta:'6–8 வாரங்கள், சிறகு தோலில் ஊசி', dose_en:'As per vaccine label', dose_ta:'தடுப்பூசி லேபிளின்படி'},
    ],
    deworming:{en:'Deworm birds kept on open ground every 2–3 months as advised by a vet; deep-litter/caged birds need it less often.', ta:'வெளியில் திறந்த தளத்தில் வளர்க்கும் கோழிகளுக்கு 2–3 மாதங்களுக்கு ஒரு முறை வார்ம் நீக்கம் செய்யவும்; கூண்டில் வளர்க்கும் கோழிகளுக்கு குறைவாக தேவைப்படும்.'},
  },
};
