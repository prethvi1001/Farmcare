/* FarmCare AI — Sample veterinarian directory (demo data only) */
"use strict";


/* ---------------- Demo vet data (clearly labelled, not real) ---------------- */
function demoVets(lat, lng){
  const base = [
    {name:'Govt. Veterinary Dispensary', distanceKm:1.2, phone:'104'},
    {name:'Community Animal Health Centre', distanceKm:3.4, phone:'104'},
    {name:'Mobile Veterinary Unit', distanceKm:5.1, phone:'1962'},
  ];
  return base;
}
