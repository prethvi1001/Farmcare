/* FarmCare AI — Rule-based symptom analysis, first-aid by risk level and voice replies */
"use strict";


/* ---------------- Mock AI engines ---------------- */
const SYMPTOM_KEYWORDS = [
  {keys:['fever','காய்ச்சல்','வெப்பம்'], en:'possible fever', ta:'காய்ச்சல் இருக்கலாம்'},
  {keys:['not eating','appetite','சாப்பிடவில்லை','உணவு'], en:'loss of appetite', ta:'உணவு உண்ணாமை'},
  {keys:['limp','leg','நொண்டி','கால்'], en:'lameness / leg difficulty', ta:'நொண்டி / கால் சிரமம்'},
  {keys:['cough','breath','இருமல்','மூச்சு'], en:'coughing or breathing difficulty', ta:'இருமல் / மூச்சு சிரமம்'},
  {keys:['diarrhea','loose motion','வயிற்றுப்போக்கு'], en:'diarrhea', ta:'வயிற்றுப்போக்கு'},
  {keys:['swelling','வீக்கம்'], en:'swelling', ta:'வீக்கம்'},
  {keys:['weak','weakness','சோர்வு','பலவீனம்'], en:'weakness / lethargy', ta:'சோர்வு'},
  {keys:['bleeding','ரத்தம்'], en:'bleeding', ta:'ரத்தப்போக்கு'},
  {keys:['egg','முட்டை'], en:'drop in egg production', ta:'முட்டை உற்பத்தி குறைவு'},
  {keys:['milk','பால்'], en:'drop in milk yield', ta:'பால் உற்பத்தி குறைவு'},
];


function analyzeScan(){
  const text = (state.scan.symptomsText||'').toLowerCase();
  const matched = SYMPTOM_KEYWORDS.filter(s=>s.keys.some(k=>text.includes(k.toLowerCase())));
  const hasPhoto = !!state.scan.photoData;
  let risk = 'low';
  const emergencyHit = matched.some(m=>['bleeding','possible fever','coughing or breathing difficulty'].includes(m.en)) && matched.length>=2;
  if(matched.some(m=>m.en==='bleeding')) risk='emergency';
  else if(matched.length>=3) risk='high';
  else if(matched.length>=1) risk='moderate';
  else risk='low';

  const visible = hasPhoto
    ? {en:'A photo was provided. General posture and visible body condition can be reviewed, but skin, coat and eye details should be checked closely by a veterinarian in person — this cannot confirm a diagnosis from the image alone.',
       ta:'புகைப்படம் வழங்கப்பட்டுள்ளது. உடல் நிலை பொதுவாக பார்க்கப்படலாம், ஆனால் தோல், ரோமம், கண் விவரங்களை கால்நடை மருத்துவர் நேரில் பரிசோதிக்க வேண்டும். படத்தால் மட்டும் உறுதியான நோய் கண்டறிய முடியாது.'}
    : {en:'No photo was provided, so no visible signs could be assessed from an image.', ta:'புகைப்படம் வழங்கப்படவில்லை, எனவே படத்தின் மூலம் தெரியக்கூடிய அறிகுறிகள் மதிப்பீடு செய்யப்படவில்லை.'};

  const reported = matched.length
    ? matched.map(m=>({en:m.en, ta:m.ta}))
    : [{en:'No specific symptoms were recognised from what was typed or spoken. Try describing what the animal is doing differently.', ta:'குறிப்பிட்ட அறிகுறிகள் இனங்காணப்படவில்லை. விலங்கு என்ன மாறுபட்டு நடந்துகொள்கிறது என விவரிக்கவும்.'}];

  const causesMap = {
    cow:{en:['Infectious illness (e.g. viral or bacterial infection)','Digestive upset','Heat stress or environmental factors','Mastitis (if milk drop reported)'],
         ta:['தொற்று நோய் (வைரஸ் / பாக்டீரியா)','செரிமான கோளாறு','வெப்ப அழுத்தம்','பால் குறைவு இருந்தால் மேஸ்டைடிஸ் இருக்கலாம்']},
    goat:{en:['Parasitic infection','Digestive upset','Respiratory infection','Nutritional deficiency'],
          ta:['ஒட்டுண்ணி தொற்று','செரிமான கோளாறு','சுவாச தொற்று','ஊட்டச்சத்து குறைபாடு']},
    sheep:{en:['Parasitic infection','Foot rot (if lameness reported)','Respiratory infection','Nutritional deficiency'],
           ta:['ஒட்டுண்ணி தொற்று','கால் அழுகல் (நொண்டி இருந்தால்)','சுவாச தொற்று','ஊட்டச்சத்து குறைபாடு']},
    hen:{en:['Viral or bacterial infection','Parasites (mites/worms)','Nutritional deficiency','Heat stress (if egg drop reported)'],
         ta:['வைரஸ் / பாக்டீரியா தொற்று','ஒட்டுண்ணிகள்','ஊட்டச்சத்து குறைபாடு','முட்டை குறைவு இருந்தால் வெப்ப அழுத்தம்']},
  };
  const causes = causesMap[state.scan.animalType] || causesMap.cow;

  return {
    animal: state.scan.animalType,
    visible, reported, causes, risk,
    photoData: state.scan.photoData,
    symptomsText: state.scan.symptomsText,
  };
}


const FIRST_AID = {
  low:{en:['Keep the animal in a clean, shaded, well-ventilated space.','Ensure clean drinking water is available.','Observe closely over the next 12–24 hours for any change.'],
       ta:['விலங்கை சுத்தமான, நிழலான, காற்றோட்டமான இடத்தில் வைக்கவும்.','சுத்தமான குடிநீர் கிடைக்கச் செய்யவும்.','அடுத்த 12–24 மணி நேரம் கவனமாக கண்காணிக்கவும்.']},
  moderate:{en:['Move the animal to a clean, shaded and well-ventilated area.','Provide access to clean drinking water.','Keep the animal separated from the herd/flock if infection is suspected.','Monitor temperature and behaviour if a thermometer is available.','Contact a veterinarian for examination.'],
            ta:['விலங்கை சுத்தமான, நிழலான, காற்றோட்டமான இடத்தில் வைக்கவும்.','சுத்தமான குடிநீர் கிடைக்கச் செய்யவும்.','தொற்று சந்தேகம் இருந்தால் மற்ற விலங்குகளிலிருந்து தனியாக வைக்கவும்.','தெர்மாமீட்டர் இருந்தால் உடல் வெப்பநிலையை கண்காணிக்கவும்.','கால்நடை மருத்துவரை தொடர்பு கொள்ளவும்.']},
  high:{en:['Separate the animal from others immediately.','Keep it calm, shaded, and comfortable — avoid unnecessary handling.','Do not attempt to medicate on your own.','Contact a veterinarian as soon as possible.'],
        ta:['விலங்கை உடனடியாக மற்றவைகளிலிருந்து பிரிக்கவும்.','அதை அமைதியாக, நிழலில் வைக்கவும் — தேவையற்ற கையாளுதலை தவிர்க்கவும்.','சொந்தமாக மருந்து கொடுக்க வேண்டாம்.','கால்நடை மருத்துவரை உடனடியாக தொடர்பு கொள்ளவும்.']},
  emergency:{en:['This may be an emergency. Keep the animal still and calm.','Do not give any medicine or home remedy.','Contact a veterinarian or emergency animal service immediately.','If bleeding, apply gentle clean pressure with a clean cloth only if it is safe to do so.'],
             ta:['இது அவசர நிலையாக இருக்கலாம். விலங்கை அசையாமல், அமைதியாக வைக்கவும்.','எந்த மருந்தும் / வீட்டு வைத்தியமும் கொடுக்க வேண்டாம்.','உடனடியாக கால்நடை மருத்துவர் அல்லது அவசர சேவையை தொடர்பு கொள்ளவும்.','ரத்தப்போக்கு இருந்தால், பாதுகாப்பானதாக இருந்தால் மட்டும் சுத்தமான துணியால் மென்மையாக அழுத்தவும்.']},
};



function ruleBasedVoiceReply(text){
  const t = (text||'').toLowerCase();
  const matched = SYMPTOM_KEYWORDS.filter(s=>s.keys.some(k=>t.includes(k.toLowerCase())));
  if(matched.length===0){
    return {
      en:"I couldn't understand a clear symptom. Please describe what the animal is doing differently — for example, not eating, coughing, or limping.",
      ta:"தெளிவான அறிகுறி புரியவில்லை. விலங்கு எப்படி மாறுபட்டு நடந்துகொள்கிறது எனச் சொல்லுங்கள் — உதாரணம்: சாப்பிடவில்லை, இருமல், நொண்டி."
    };
  }
  const hasFever = matched.some(m=>m.en==='possible fever');
  const hasBleeding = matched.some(m=>m.en==='bleeding');
  if(hasBleeding){
    return {
      en:"This sounds serious. Keep the animal calm and still, do not give any medicine, and contact a veterinarian immediately.",
      ta:"இது தீவிரமாக இருக்கலாம். விலங்கை அமைதியாக வைக்கவும், மருந்து கொடுக்க வேண்டாம், உடனடியாக கால்நடை மருத்துவரை தொடர்பு கொள்ளுங்கள்."
    };
  }
  if(hasFever){
    return {
      en:"Measure the animal's body temperature if you can. Give clean water and keep it in a shaded place. Do not give medicine without a veterinarian's advice. If the fever continues, contact a veterinarian right away.",
      ta:"மாட்டின் உடல் வெப்பநிலையை சரியாக அளவிடுங்கள். சுத்தமான தண்ணீர் கொடுத்து நிழலான இடத்தில் வைக்கவும். மருத்துவர் ஆலோசனை இல்லாமல் மருந்து கொடுக்க வேண்டாம். காய்ச்சல் தொடர்ந்தால் உடனடியாக கால்நடை மருத்துவரை அணுகுங்கள்."
    };
  }
  return {
    en:"Keep the animal in a clean, shaded space with fresh water, and watch it closely for the next day. If it does not improve, or gets worse, please contact a veterinarian.",
    ta:"விலங்கை சுத்தமான, நிழலான இடத்தில் சுத்தமான தண்ணீருடன் வைத்து, அடுத்த நாள் கவனமாக கவனிக்கவும். மேம்படவில்லை அல்லது மோசமானால், கால்நடை மருத்துவரை தொடர்பு கொள்ளுங்கள்."
  };
}
