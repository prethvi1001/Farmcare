/* FarmCare AI — Event wiring and all button/action handlers */
"use strict";


/* ---------------- Event handlers ---------------- */
function attachHandlers(){
  document.querySelectorAll('[data-nav]').forEach(el=>{
    el.addEventListener('click', ()=> go(el.getAttribute('data-nav')));
  });
  document.querySelectorAll('[data-action]').forEach(el=>{
    el.addEventListener('click', (e)=> handleAction(el.getAttribute('data-action'), el, e));
  });

  const photoInput = document.getElementById('photoInput');
  if(photoInput) photoInput.addEventListener('change', (e)=> handlePhoto(e, (data)=>{ state.scan.photoData = data; render(); }));

  const newAnimalPhoto = document.getElementById('newAnimalPhoto');
  if(newAnimalPhoto) newAnimalPhoto.addEventListener('change', (e)=> handlePhoto(e, (data)=>{
    state._newAnimalPhoto = data;
    document.getElementById('newPhotoPreviewWrap').innerHTML = `<img class="photo-preview" src="${data}">`;
  }));

  const symptomsText = document.getElementById('symptomsText');
  if(symptomsText) symptomsText.addEventListener('input', (e)=> state.scan.symptomsText = e.target.value);

  const micScanBtn = document.getElementById('micScanBtn');
  if(micScanBtn) micScanBtn.addEventListener('click', ()=> startDictation((text)=>{
    state.scan.symptomsText = (state.scan.symptomsText? state.scan.symptomsText+' ' : '') + text;
    render();
  }));

  const voiceMicBtn = document.getElementById('voiceMicBtn');
  if(voiceMicBtn) voiceMicBtn.addEventListener('click', ()=>{
    startDictation((text)=>{
      state.voice.transcript = text;
      state.voice.reply = ruleBasedVoiceReply(text);
      render();
      speak(state.lang==='en' ? state.voice.reply.en : state.voice.reply.ta, speechLangCode());
    }, ()=>{ state.voice.listening = true; render(); }, ()=>{ state.voice.listening = false; render(); });
  });

  const voiceSendBtn = document.getElementById('voiceSendBtn');
  if(voiceSendBtn) voiceSendBtn.addEventListener('click', ()=>{
    const val = document.getElementById('voiceTypeInput').value.trim();
    if(!val) return;
    state.voice.transcript = val;
    state.voice.reply = ruleBasedVoiceReply(val);
    render();
  });

  const listenBtn = document.getElementById('listenBtn');
  if(listenBtn) listenBtn.addEventListener('click', ()=>{
    if(state.voice.reply) speak(state.lang==='en' ? state.voice.reply.en : (state.lang==='ta' ? state.voice.reply.ta : state.voice.reply.ta + '. ' + state.voice.reply.en), speechLangCode());
  });

  const locateBtn = document.getElementById('locateBtn');
  if(locateBtn) locateBtn.addEventListener('click', ()=>{
    const statusEl = document.getElementById('locateStatus');
    statusEl.innerHTML = bi('Getting location...', 'இருப்பிடம் பெறப்படுகிறது...','1');
    if(!navigator.geolocation){ statusEl.innerHTML = bi('Location not supported on this device.', 'இந்த சாதனத்தில் இருப்பிடம் ஆதரிக்கப்படவில்லை.','1'); return; }
    navigator.geolocation.getCurrentPosition(
      (pos)=>{ statusEl.innerHTML = `📍 ${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)} — ${bi('showing sample nearby services below', 'கீழே மாதிரி அருகிலுள்ள சேவைகள் காட்டப்படுகின்றன','1')}`; },
      (err)=>{ statusEl.innerHTML = bi('Location permission denied or unavailable.', 'இருப்பிட அனுமதி மறுக்கப்பட்டது அல்லது கிடைக்கவில்லை.','1'); }
    );
  });

  const emgLocateBtn = document.getElementById('emgLocateBtn');
  if(emgLocateBtn) emgLocateBtn.addEventListener('click', ()=>{
    const statusEl = document.getElementById('emgStatus');
    statusEl.innerHTML = bi('Getting location...', 'இருப்பிடம் பெறப்படுகிறது...','1');
    if(!navigator.geolocation){ statusEl.innerHTML = bi('Location not supported on this device.', 'இந்த சாதனத்தில் இருப்பிடம் ஆதரிக்கப்படவில்லை.','1'); return; }
    navigator.geolocation.getCurrentPosition(
      (pos)=>{ statusEl.innerHTML = `📍 ${bi('Location found','இருப்பிடம் கண்டறியப்பட்டது','1')}: ${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)}`; },
      (err)=>{ statusEl.innerHTML = bi('Location permission denied or unavailable.', 'இருப்பிட அனுமதி மறுக்கப்பட்டது அல்லது கிடைக்கவில்லை.','1'); }
    );
  });

  const startShareBtn = document.getElementById('startShareBtn');
  if(startShareBtn) startShareBtn.addEventListener('click', ()=>{
    if(!navigator.geolocation){ state.liveShare.active = true; render(); return; }
    navigator.geolocation.getCurrentPosition(
      (pos)=>{
        state.liveShare.active = true;
        render();
        const el = document.getElementById('liveLocData');
        if(el) el.innerHTML = `${bi('Your location','உங்கள் இருப்பிடம')}: ${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)}<br><span class="small-muted">${bi('Demo link — connect messaging/maps service to send a real live link.', 'மாதிரி இணைப்பு — உண்மையான நேரடி இணைப்பை அனுப்ப செய்தி/வரைபட சேவையை இணைக்கவும்.')}</span>`;
      },
      ()=>{ state.liveShare.active = true; render(); }
    );
  });
  const stopShareBtn = document.getElementById('stopShareBtn');
  if(stopShareBtn) stopShareBtn.addEventListener('click', ()=>{ state.liveShare = {active:false, vetName:null}; render(); });
}


function handlePhoto(e, cb){
  const file = e.target.files && e.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = ()=> cb(reader.result);
  reader.readAsDataURL(file);
}


function startDictation(onResult, onStart, onEnd){
  const rec = getRecognition(speechLangCode());
  if(!rec){
    alert('Voice input is not supported in this browser. Please type instead.\nகுரல் உள்ளீடு இந்த உலாவியில் ஆதரிக்கப்படவில்லை. தட்டச்சு செய்யவும்.');
    return;
  }
  if(onStart) onStart();
  rec.onresult = (e)=>{
    const text = e.results[0][0].transcript;
    if(onEnd) onEnd();
    onResult(text);
  };
  rec.onerror = ()=>{ if(onEnd) onEnd(); };
  rec.onend = ()=>{ if(onEnd) onEnd(); };
  try{ rec.start(); }catch(e){ if(onEnd) onEnd(); }
}


function handleAction(action, el){
  switch(action){
    case 'setLang':
      state.lang = el.getAttribute('data-lang');
      render();
      break;
    case 'sendOtp': {
      const mobile = document.getElementById('mobileInput').value.trim();
      if(!/^\d{10}$/.test(mobile)){
        state.auth.error = bi('Please enter a valid 10-digit mobile number.', 'சரியான 10 இலக்க மொபைல் எண்ணை உள்ளிடவும்.','1');
        render();
        break;
      }
      state.auth.mobile = mobile;
      state.auth.generatedOtp = (mobile === DEMO_CREDENTIALS.mobile) ? DEMO_CREDENTIALS.otp : String(Math.floor(1000+Math.random()*9000));
      state.auth.otp = '';
      state.auth.error = '';
      state.auth.step = 'otp';
      render();
      break;
    }
    case 'verifyOtp': {
      const otp = document.getElementById('otpInput').value.trim();
      if(otp === state.auth.generatedOtp){
        state.auth = { step:'mobile', mobile:'', otp:'', generatedOtp:'', error:'' };
        go('home');
      } else {
        state.auth.error = bi('Incorrect OTP. Please check the demo OTP shown below and try again.', 'தவறான OTP. கீழே உள்ள டெமோ OTP-ஐ சரிபார்த்து மீண்டும் முயற்சிக்கவும்.','1');
        render();
      }
      break;
    }
    case 'changeMobile':
      state.auth = { step:'mobile', mobile:'', otp:'', generatedOtp:'', error:'' };
      render();
      break;
    case 'guestLogin':
      state.auth = { step:'mobile', mobile:'', otp:'', generatedOtp:'', error:'' };
      go('home');
      break;
    case 'logout':
      state.auth = { step:'mobile', mobile:'', otp:'', generatedOtp:'', error:'' };
      go('login');
      break;
    case 'selectAnimalHome':
      state.scan.animalType = el.getAttribute('data-id');
      go('scan');
      break;
    case 'setScanAnimal':
      state.scan.animalType = el.getAttribute('data-id');
      render();
      break;
    case 'setFeedAnimal':
      state.animalTypeFilter = el.getAttribute('data-id');
      render();
      break;
    case 'setFirstAidAnimal':
      state.firstAid.animalType = el.getAttribute('data-id');
      state.firstAid.topicId = null;
      render();
      break;
    case 'setFirstAidTopic':
      state.firstAid.topicId = el.getAttribute('data-id');
      render();
      break;
    case 'setVaccGuideAnimal':
      state.vaccGuideAnimal = el.getAttribute('data-id');
      render();
      break;
    case 'runAnalysis':
      state.scan.symptomsText = document.getElementById('symptomsText') ? document.getElementById('symptomsText').value : state.scan.symptomsText;
      state.scan.result = analyzeScan();
      go('scanResult');
      break;
    case 'shareLoc':
      state.liveShare.vetName = el.getAttribute('data-vet');
      go('liveLocation');
      break;
    case 'openVaccinationPicker':
      render();
      break;
    case 'goVaccAnimal':
      state.selectedAnimalId = el.getAttribute('data-id');
      go('vaccinationAnimal');
      break;
    case 'fillVaccFromGuide': {
      const a = getAnimal(state.selectedAnimalId);
      if(!a) return;
      const guide = VACCINATION_GUIDE[a.type] || VACCINATION_GUIDE.cow;
      const idx = parseInt(el.getAttribute('data-idx'), 10);
      const v = guide.vaccines[idx];
      if(!v) return;
      document.getElementById('vaccName').value = v.name_en;
      document.getElementById('vaccVolume').value = v.dose_en;
      document.getElementById('vaccSeason').value = v.season_en;
      break;
    }
    case 'addVaccination': {
      const a = getAnimal(state.selectedAnimalId);
      if(!a) return;
      const name = document.getElementById('vaccName').value.trim();
      const volume = document.getElementById('vaccVolume').value.trim();
      const season = document.getElementById('vaccSeason').value.trim();
      const dateGiven = document.getElementById('vaccDate').value;
      const nextDue = document.getElementById('vaccNext').value;
      if(!name || !nextDue){ alert('Please enter vaccine name and next due date.\nதடுப்பூசி பெயர் மற்றும் அடுத்த தேதியை உள்ளிடவும்.'); return; }
      a.vaccinations = a.vaccinations || [];
      a.vaccinations.push({id:uid('vac'), name, volume, season, dateGiven, nextDue});
      saveAnimal(a).then(render);
      break;
    }
    case 'goRecordDetail':
      state.selectedAnimalId = el.getAttribute('data-id');
      go('recordDetail');
      break;
    case 'saveNewAnimal': {
      const name = document.getElementById('raName').value.trim();
      const breed = document.getElementById('raBreed').value.trim();
      const sex = document.getElementById('raSex').value;
      const age = document.getElementById('raAge').value;
      const weight = document.getElementById('raWeight').value;
      const notes = document.getElementById('raNotes').value.trim();
      const animal = {
        id: uid('a'),
        type: state.scan.animalType,
        name, breed, sex, age, weight, notes,
        photoData: state._newAnimalPhoto || null,
        vaccinations: [],
        createdAt: Date.now(),
      };
      state.animals.unshift(animal);
      state._newAnimalPhoto = null;
      saveAnimal(animal).then(()=> go('recordDetail', {selectedAnimalId: animal.id}));
      break;
    }
    case 'deleteAnimalConfirm': {
      const id = el.getAttribute('data-id');
      if(confirm('Delete this animal record? / இந்த பதிவை நீக்கவா?')){
        deleteAnimal(id).then(()=> go('records'));
      }
      break;
    }
  }
}
