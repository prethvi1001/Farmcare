/* FarmCare AI — Feed management screen */
"use strict";


function renderFeed(){
  const g = FEED_GUIDE[state.animalTypeFilter] || FEED_GUIDE.cow;
  const am = animalMeta(state.animalTypeFilter);
  return `
  <div class="screen">
    ${topBar('Feed Management','தீவன மேலாண்மை')}
    ${renderAnimalTypePicker(state.animalTypeFilter, 'setFeedAnimal')}

    <div class="card" style="background:var(--surface-2);">
      <div class="section-title">${am.ic} ${bi('Daily Ration','தினசரி தீவன அளவு')}</div>
      <div class="small-muted">${bi(g.weight_en, g.weight_ta)}</div>
    </div>

    ${g.rows.map(r=>`
      <div class="card">
        <div class="section-title">${r.ic} ${bi(r.en, r.ta)}</div>
        <div style="background:var(--surface-2);border-radius:10px;padding:10px 12px;margin-bottom:10px;">
          <div style="font-weight:800;font-size:15px;">${r.qty_en}</div>
          <div class="small-muted" style="font-weight:600;">${r.qty_ta}</div>
        </div>
        <p style="font-size:13.5px;margin:0;">${r.note_en}</p>
        <p style="font-size:12.5px;color:var(--ink-soft);margin:6px 0 0 0;">${r.note_ta}</p>
      </div>`).join('')}

    <div class="card">
      <div class="section-title">💡 ${bi('Feeding Tips','தீவன குறிப்புகள்')}</div>
      <div style="font-size:12.5px;font-weight:800;color:var(--ink-soft);margin-bottom:6px;">English</div>
      <ul class="bullets">${g.tips_en.map(x=>`<li>${x}</li>`).join('')}</ul>
      <div class="divider"></div>
      <div style="font-size:12.5px;font-weight:800;color:var(--ink-soft);margin-bottom:6px;">தமிழ்</div>
      <ul class="bullets">${g.tips_ta.map(x=>`<li>${x}</li>`).join('')}</ul>
    </div>

    <div class="info-box">${bi('These are general daily quantities for an average healthy adult animal. Actual amounts change with breed, body weight, age, pregnancy, milk or egg yield, season and the quality of fodder available. Confirm a detailed feed plan with a livestock extension officer or veterinarian.', 'இவை சராசரி ஆரோக்கியமான வயது வந்த விலங்கிற்கான பொதுவான தினசரி அளவுகள். உண்மையான அளவு இனம், உடல் எடை, வயது, கர்ப்பம், பால்/முட்டை உற்பத்தி, பருவம் மற்றும் கிடைக்கும் தீவனத்தின் தரத்தைப் பொறுத்து மாறும். விரிவான தீவன திட்டத்திற்கு கால்நடை விரிவாக்க அதிகாரி அல்லது மருத்துவரிடம் உறுதி செய்யவும்.')}</div>
  </div>
  ${bottomNav('home')}`;
}
