/* FarmCare AI — Splash screen and login screen */
"use strict";


function renderSplash(){
  return `
  <div class="login-wrap" style="justify-content:center;align-items:center;text-align:center;">
    <img class="app-logo-badge" src="${LOGO_IMG_DATA}" alt="FarmCare AI logo">
    <div class="brand-title">FarmCare AI</div>
    <div class="brand-sub bi" style="margin-bottom:8px;"><span class="en">Smart Livestock Management</span><span class="ta">ஸ்மார்ட் கால்நடை மேலாண்மை</span></div>
    <div class="spinner" aria-label="Loading"></div>
    <div class="small-muted" style="color:#DCE8DD;margin-top:14px;">${bi('Loading...','ஏற்றுகிறது...','1')}</div>
  </div>`;
}


function renderLogin(){
  const a = state.auth;
  return `
  <div class="login-wrap">
    <img class="app-logo-badge" src="${LOGO_IMG_DATA}" alt="FarmCare AI logo">
    <div class="brand-title">FarmCare AI</div>
    <div class="brand-sub bi"><span class="en">Smart Livestock Management</span><span class="ta">ஸ்மார்ட் கால்நடை மேலாண்மை</span></div>

    <div class="lang-toggle">
      <button class="${state.lang==='ta'?'active':''}" data-action="setLang" data-lang="ta">தமிழ்</button>
      <button class="${state.lang==='en'?'active':''}" data-action="setLang" data-lang="en">English</button>
    </div>

    <div class="login-card">
      ${a.step==='mobile' ? `
        <div class="field">
          <label>${bi('Mobile Number','மொபைல் எண்','1')}</label>
          <input type="text" id="mobileInput" inputmode="numeric" maxlength="10" placeholder="e.g. 9876543210" value="${a.mobile||''}">
        </div>
        ${a.error?`<div class="warn-box" style="margin-bottom:14px;">${a.error}</div>`:''}
        <div class="stack">
          <button class="btn btn-primary" data-action="sendOtp">📲 ${bi('Send OTP','OTP அனுப்ப','1')}</button>
          <button class="btn btn-gold" data-action="guestLogin">${bi('Continue as Guest','விருந்தினராக தொடர','1')}</button>
        </div>
        <div class="small-muted" style="margin-top:12px;text-align:center;">${bi('Demo mobile number','டெமோ மொபைல் எண்','1')}: <b>${DEMO_CREDENTIALS.mobile}</b></div>
      ` : `
        <div class="field">
          <label>${bi('Enter OTP','OTP-ஐ உள்ளிடவும்','1')}</label>
          <div class="small-muted" style="margin-bottom:8px;">${bi('Sent to','அனுப்பப்பட்டது','1')} ${a.mobile}</div>
          <input type="text" id="otpInput" inputmode="numeric" maxlength="6" placeholder="••••">
        </div>
        ${a.error?`<div class="warn-box" style="margin-bottom:14px;">${a.error}</div>`:''}
        <div class="stack">
          <button class="btn btn-primary" data-action="verifyOtp">✅ ${bi('Verify & Login','சரிபார்த்து உள்நுழைய','1')}</button>
          <button class="btn btn-ghost" data-action="changeMobile">${bi('Change Number','எண்ணை மாற்ற','1')}</button>
          <button class="btn btn-gold" data-action="guestLogin">${bi('Continue as Guest','விருந்தினராக தொடர','1')}</button>
        </div>
        <div class="small-muted" style="margin-top:12px;text-align:center;">${bi('Demo OTP','டெமோ OTP','1')}: <b>${a.generatedOtp}</b></div>
      `}
    </div>
  </div>`;
}
