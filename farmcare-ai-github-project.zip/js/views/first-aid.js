/* FarmCare AI — First aid (after scan), First Aid Library and Medicine information */
"use strict";


function renderFirstAid(){
  const r = state.scan.result;
  const risk = r ? r.risk : 'moderate';
  const fa = FIRST_AID[risk];
  return `
  <div class="screen">
    ${topBar('First Aid','முதலுதவி','scanResult')}
    ${r?`<div style="margin-bottom:12px;">${riskChip(risk)}</div>`:''}
    <div class="card">
      <div class="section-title">English</div>
      <ul class="bullets">${fa.en.map(x=>`<li>${x}</li>`).join('')}</ul>
    </div>
    <div class="card">
      <div class="section-title">தமிழ்</div>
      <ul class="bullets">${fa.ta.map(x=>`<li>${x}</li>`).join('')}</ul>
    </div>
    <div class="warn-box">⚠️ ${bi('Do not attempt dangerous home remedies. This is general guidance, not a substitute for veterinary care.', 'ஆபத்தான வீட்டு வைத்தியங்களை முயற்சிக்க வேண்டாம். இது பொது வழிகாட்டுதல் மட்டுமே, கால்நடை மருத்துவ சிகிச்சைக்கு மாற்றாக அல்ல.')}</div>
    <button class="btn btn-primary" data-nav="medicine">💊 ${bi('Medicine Information','மருந்து தகவல்','1')}</button>
    <div style="height:10px;"></div>
    <button class="btn btn-ghost" data-nav="firstAidLibrary">📖 ${bi('First Aid Library (all topics)','முதலுதவி நூலகம் (அனைத்து தலைப்புகள்)','1')}</button>
    <div style="height:10px;"></div>
    <button class="btn btn-emg" data-nav="vetFinder">🏥 ${bi('Contact a Veterinarian','மருத்துவரை தொடர்பு கொள்ள','1')}</button>
  </div>
  ${bottomNav('home')}`;
}


function renderFirstAidLibrary(){
  const fa = state.firstAid;
  const topics = FIRST_AID_TOPICS[fa.animalType] || FIRST_AID_TOPICS.cow;
  const active = fa.topicId ? topics.find(t=>t.id===fa.topicId) : null;
  return `
  <div class="screen">
    ${topBar('First Aid Library','முதலுதவி நூலகம்')}
    <div class="section-title">${bi('Select Animal','விலங்கை தேர்ந்தெடுக்கவும்')}</div>
    ${renderAnimalTypePicker(fa.animalType, 'setFirstAidAnimal')}

    <div class="section-title">${bi('Select Topic','தலைப்பை தேர்ந்தெடுக்கவும்')}</div>
    <div id="firstAidTopicList" style="margin-bottom:16px;">
      ${topics.map(t=>{
        const isActive = !!(active && active.id===t.id);
        return `<button type="button" class="list-item${isActive?' topic-active':''}" data-action="setFirstAidTopic" data-id="${t.id}">
          <div style="display:flex;align-items:center;gap:10px;">
            <span style="font-size:22px;">${t.ic}</span>
            ${bi(t.en, t.ta)}
          </div>
          <span>${isActive?'▲':'▼'}</span>
        </button>`;
      }).join('')}
    </div>

    ${active ? `
      <div class="card">
        <div class="section-title">${active.ic} ${bi(active.en, active.ta)}</div>
        <div class="divider"></div>
        <div style="font-size:12.5px;font-weight:800;color:var(--ink-soft);margin-bottom:6px;">English</div>
        <ul class="bullets">${active.en_steps.map(x=>`<li>${x}</li>`).join('')}</ul>
        <div class="divider"></div>
        <div style="font-size:12.5px;font-weight:800;color:var(--ink-soft);margin-bottom:6px;">தமிழ்</div>
        <ul class="bullets">${active.ta_steps.map(x=>`<li>${x}</li>`).join('')}</ul>
      </div>
      <div class="warn-box">⚠️ ${bi('General guidance only, not a substitute for veterinary care. For emergencies, seek immediate professional help.', 'இது பொது வழிகாட்டுதல் மட்டுமே, கால்நடை மருத்துவ சிகிச்சைக்கு மாற்றாக அல்ல. அவசரநிலையில் உடனடியாக தொழில்முறை உதவியை நாடுங்கள்.')}</div>
      <button class="btn btn-emg" data-nav="vetFinder">🏥 ${bi('Contact a Veterinarian','மருத்துவரை தொடர்பு கொள்ள','1')}</button>
    ` : emptyState('Choose a topic above to see first aid steps.', 'மேலே ஒரு தலைப்பை தேர்ந்தெடுத்து முதலுதவி படிகளை பார்க்கவும்.')}
  </div>
  ${bottomNav('home')}`;
}


function renderMedicine(){
  return `
  <div class="screen">
    ${topBar('Medicine','மருந்து')}
    <div class="card">
      <div class="section-title">${bi('Treatment Categories a Vet May Consider','மருத்துவர் பரிசீலிக்கக்கூடிய சிகிச்சை வகைகள்')}</div>
      <ul class="bullets">
        <li>${bi('Antibiotics','நுண்ணுயிர் எதிர்ப்பிகள்','1')}<div class="small-muted">${bi('For suspected bacterial infection, only on veterinary advice', 'பாக்டீரியா தொற்று சந்தேகம் இருந்தால் மட்டும், மருத்துவர் ஆலோசனையுடன்')}</div></li>
        <li>${bi('Antiparasitics / Dewormers','ஒட்டுண்ணி நீக்கிகள்','1')}<div class="small-muted">${bi('For worm or external parasite load', 'புழு அல்லது வெளி ஒட்டுண்ணி பாதிப்புக்கு')}</div></li>
        <li>${bi('Anti-inflammatory / Pain relief','வலி நிவாரணி','1')}<div class="small-muted">${bi('For pain, swelling or fever, vet-dosed', 'வலி, வீக்கம் அல்லது காய்ச்சலுக்கு, மருத்துவர் அளவீட்டில்')}</div></li>
        <li>${bi('Vitamins & Supplements','வைட்டமின்கள்','1')}<div class="small-muted">${bi('For general recovery and nutrition support', 'பொது குணமடைதல் மற்றும் ஊட்டச்சத்து ஆதரவுக்கு')}</div></li>
      </ul>
    </div>

    <div class="warn-box">
      ⚠️ ${bi('Veterinary Safety','கால்நடை பாதுகாப்பு')}
      <div style="height:8px;"></div>
      <div style="font-size:13.5px;">"மருந்தின் பெயர் மற்றும் அளவு நோயின் காரணம், மாட்டின் எடை, வயது மற்றும் உடல்நிலையைப் பொறுத்தது. கால்நடை மருத்துவரின் ஆலோசனை இல்லாமல் மருந்து கொடுக்க வேண்டாம்."</div>
      <div style="height:8px;"></div>
      <div style="font-size:13.5px;">"Do not give human medicines to livestock unless specifically instructed by a veterinarian."</div>
    </div>

    <div class="info-box">${bi('This app does not prescribe medicine, dosage or treatment duration from a photograph alone. Always confirm with a licensed veterinarian.', 'இந்த ஆப் புகைப்படத்தை மட்டும் வைத்து மருந்து, அளவு அல்லது சிகிச்சை காலத்தை பரிந்துரைக்காது. எப்போதும் உரிமம் பெற்ற கால்நடை மருத்துவரிடம் உறுதி செய்யவும்.')}</div>

    <button class="btn btn-ghost" data-nav="recordAdd">📋 ${bi('Save a Prescription to a Record','பரிந்துரையை பதிவில் சேமிக்க','1')}</button>
  </div>
  ${bottomNav('home')}`;
}
