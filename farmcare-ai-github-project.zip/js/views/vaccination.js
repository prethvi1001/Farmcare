/* FarmCare AI — Vaccination hub, guide and per-animal vaccination records */
"use strict";


/* ---- Vaccination ---- */
function renderVaccinationHub(){
  return `
  <div class="screen">
    ${topBar('Records','பதிவுகள்')}
    <div class="tile-grid">
      <button class="tile accent-gold" data-nav="records">
        <span class="ic">📋</span>${bi('Animal Records','விலங்கு பதிவுகள்')}
      </button>
      <button class="tile accent-sky" data-nav="vaccinationGuide">
        <span class="ic">💉</span>${bi('Vaccination Guide','தடுப்பூசி வழிகாட்டி')}
      </button>
    </div>
    <div class="divider"></div>
    <div class="section-title">${bi('Choose an Animal for Vaccination Records','தடுப்பூசி பதிவுகளுக்கு விலங்கை தேர்ந்தெடு')}</div>
    ${state.animals.length===0 ? emptyState('No animals yet — add one in Animal Records.', 'இன்னும் விலங்கு இல்லை — விலங்கு பதிவுகளில் ஒன்றை சேர்க்கவும்.') :
      state.animals.map(a=>animalListItem(a, ()=>{})).join('')}
  </div>
  ${bottomNav('vaccination')}`;
}


function renderVaccinationGuide(){
  const animal = state.vaccGuideAnimal;
  const g = VACCINATION_GUIDE[animal] || VACCINATION_GUIDE.cow;
  return `
  <div class="screen">
    ${topBar('Vaccination Guide','தடுப்பூசி வழிகாட்டி','vaccination')}
    ${renderAnimalTypePicker(animal, 'setVaccGuideAnimal')}

    <div class="info-box">${bi(g.intro.en, g.intro.ta)}</div>

    ${g.vaccines.map(v=>`
      <div class="card">
        <div class="section-title">💉 ${bi(v.name_en, v.name_ta)}</div>
        <div class="row" style="margin-bottom:8px;"><span class="small-muted grow">${bi('Prevents','தடுக்கும் நோய்','1')}</span><b style="text-align:right;">${v.prevents_en}<div class="small-muted">${v.prevents_ta}</div></b></div>
        <div class="row" style="margin-bottom:8px;"><span class="small-muted grow">${bi('When / Season','எப்போது / பருவம்','1')}</span><b style="text-align:right;">${v.season_en}<div class="small-muted">${v.season_ta}</div></b></div>
        <div class="row"><span class="small-muted grow">${bi('Dose / Volume','அளவு','1')}</span><b style="text-align:right;">${v.dose_en}<div class="small-muted">${v.dose_ta}</div></b></div>
      </div>`).join('')}

    <div class="card">
      <div class="section-title">🪱 ${bi('Deworming','வார்ம் நீக்கம்')}</div>
      <p style="font-size:13.5px;margin:0;">${g.deworming.en}</p>
      <p style="font-size:12.5px;color:var(--ink-soft);margin:6px 0 0 0;">${g.deworming.ta}</p>
    </div>

    <div class="warn-box">⚠️ ${bi('This is general guidance for common vaccines. Exact vaccine brand, dose and schedule vary by region, age, weight and health status — always confirm with a local veterinarian or animal husbandry officer.', 'இது பொது தடுப்பூசி வழிகாட்டுதல் மட்டுமே. உண்மையான தடுப்பூசி பெயர், அளவு மற்றும் அட்டவணை இடம், வயது, எடை மற்றும் உடல்நிலையைப் பொறுத்து மாறுபடும் — எப்போதும் உள்ளூர் கால்நடை மருத்துவர் அல்லது கால்நடை மேம்பாட்டு அதிகாரியிடம் உறுதி செய்யவும்.')}</div>
  </div>
  ${bottomNav('vaccination')}`;
}


function renderVaccinationAnimal(){
  const a = getAnimal(state.selectedAnimalId);
  if(!a) return renderVaccinationHub();
  const vaccs = (a.vaccinations||[]).slice().sort((x,y)=> new Date(x.nextDue)-new Date(y.nextDue));
  const guide = VACCINATION_GUIDE[a.type] || VACCINATION_GUIDE.cow;
  return `
  <div class="screen">
    ${topBar(a.name||'Animal', animalMeta(a.type).ta, 'vaccination')}

    <div class="card">
      <div class="section-title">📖 ${bi('Quick Fill from Guide','வழிகாட்டியிலிருந்து நிரப்ப')}</div>
      <p class="small-muted" style="margin:0 0 10px 0;">${bi('Tap a vaccine to fill in the name, volume and season below.', 'கீழே பெயர், அளவு, பருவத்தை நிரப்ப ஒரு தடுப்பூசியை தட்டவும்.')}</p>
      ${guide.vaccines.map((v,i)=>`
        <button type="button" class="list-item" data-action="fillVaccFromGuide" data-idx="${i}" style="padding:10px 12px;">
          <div>
            <div style="font-weight:800;font-size:13.5px;">${v.name_en}</div>
            <div class="meta">${v.season_en} · ${v.dose_en}</div>
          </div>
          <span>+</span>
        </button>`).join('')}
    </div>

    <div class="card">
      <div class="section-title">💉 ${bi('Add Vaccination','தடுப்பூசி சேர்')}</div>
      <div class="stack">
        <input type="text" id="vaccName" placeholder="Vaccine name / தடுப்பூசி பெயர்">
        <input type="text" id="vaccVolume" placeholder="Volume / Dose e.g. 3 ml · அளவு">
        <input type="text" id="vaccSeason" placeholder="Season / timing e.g. Before monsoon · பருவம்">
        <div class="row">
          <div>
            <label class="small-muted">${bi('Date given','கொடுத்த தேதி','1')}</label>
            <input type="date" id="vaccDate" value="${todayISO()}">
          </div>
          <div>
            <label class="small-muted">${bi('Next due','அடுத்த தேதி','1')}</label>
            <input type="date" id="vaccNext">
          </div>
        </div>
        <button class="btn btn-primary btn-sm" data-action="addVaccination">${bi('Save','சேமி','1')}</button>
      </div>
    </div>

    <div class="section-title">${bi('History','வரலாறு')}</div>
    ${vaccs.length===0 ? emptyState('No vaccination records yet.', 'இன்னும் தடுப்பூசி பதிவுகள் இல்லை.') :
      vaccs.map(v=>{
        const st = vaccStatus(v.nextDue);
        return `<div class="list-item" style="cursor:default;">
          <div>
            <div style="font-weight:800;">${v.name}</div>
            ${(v.volume||v.season) ? `<div class="meta">${[v.volume, v.season].filter(Boolean).join(' · ')}</div>` : ''}
            <div class="meta">${bi('Given','கொடுக்கப்பட்டது','1')}: ${fmtDate(v.dateGiven)} · ${bi('Next','அடுத்தது','1')}: ${fmtDate(v.nextDue)}</div>
          </div>
          <span class="status-badge ${st}">${st==='overdue'?'❌':st==='due'?'⏳':'✅'}</span>
        </div>`;
      }).join('')}

    <div class="info-box">${bi('Vaccination schedules vary by species, age, location and farm conditions — always confirm the schedule with a local veterinarian.', 'தடுப்பூசி அட்டவணைகள் இனம், வயது, இடம் மற்றும் பண்ணை நிலைமைகளைப் பொறுத்து மாறுபடும் — உள்ளூர் கால்நடை மருத்துவரிடம் உறுதி செய்யவும்.')}</div>
  </div>
  ${bottomNav('vaccination')}`;
}
