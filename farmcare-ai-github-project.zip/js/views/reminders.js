/* FarmCare AI — Reminders screen */
"use strict";


/* ---- Reminders ---- */
function renderReminders(){
  const items = [];
  state.animals.forEach(a=>{
    (a.vaccinations||[]).forEach(v=>{
      const st = vaccStatus(v.nextDue);
      if(st!=='completed'){
        items.push({animal:a, v, st});
      }
    });
  });
  items.sort((x,y)=> new Date(x.v.nextDue)-new Date(y.v.nextDue));
  return `
  <div class="screen">
    ${topBar('Reminders','நினைவூட்டல்கள்')}
    ${items.length===0 ? emptyState('No upcoming reminders. Add vaccination records to see them here.', 'வரவிருக்கும் நினைவூட்டல்கள் இல்லை. தடுப்பூசி பதிவுகள் சேர்க்கவும்.') :
      items.map(it=>{
        const am = animalMeta(it.animal.type);
        return `<div class="list-item" style="cursor:default;">
          <div>
            <div style="font-weight:800;">${am.ic} ${it.animal.name||am.en}: ${it.v.name}</div>
            <div class="meta">${bi('Due','தேதி','1')}: ${fmtDate(it.v.nextDue)}</div>
          </div>
          <span class="status-badge ${it.st}">${it.st==='overdue'?'❌ Overdue':'⏳ Due soon'}</span>
        </div>`;
      }).join('')}
  </div>
  ${bottomNav('home')}`;
}
