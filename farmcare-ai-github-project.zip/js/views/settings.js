/* FarmCare AI — Settings screen */
"use strict";


function renderSettings(){
  return `
  <div class="screen">
    ${topBar('Settings','அமைப்புகள்')}
    <div class="card">
      <div class="section-title">${bi('Language','மொழி')}</div>
      <p class="small-muted">${bi('The app shows both English and Tamil together throughout.', 'இந்த ஆப் முழுவதும் ஆங்கிலம் மற்றும் தமிழ் இரண்டையும் ஒன்றாகக் காட்டுகிறது.')}</p>
    </div>
    <div class="card">
      <div class="section-title">${bi('About','பற்றி')}</div>
      <p class="small-muted">${bi('FarmCare AI helps with photo + voice health checks, first aid guidance, vaccination reminders, animal records and finding nearby veterinary help. It does not replace professional veterinary care.', 'FarmCare AI புகைப்படம் + குரல் மூலம் உடல்நல பரிசோதனை, முதலுதவி வழிகாட்டுதல், தடுப்பூசி நினைவூட்டல், விலங்கு பதிவுகள் மற்றும் அருகிலுள்ள கால்நடை மருத்துவ உதவியை கண்டுபிடிக்க உதவுகிறது. இது தொழில்முறை கால்நடை மருத்துவ சிகிச்சைக்கு மாற்றாக அமையாது.')}</p>
    </div>
    <button class="btn btn-emg" data-action="logout">${bi('Log Out','வெளியேறு','1')}</button>
  </div>
  ${bottomNav('settings')}`;
}
