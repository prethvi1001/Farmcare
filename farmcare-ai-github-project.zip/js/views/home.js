/* FarmCare AI — Home dashboard */
"use strict";


function renderHome(){
  return `
  <div class="screen">
    <div class="greet"><span class="en">Welcome Farmer 👋</span><span class="ta">வணக்கம் விவசாயி</span></div>

    <div class="animal-grid">
      ${ANIMAL_TYPES.map(a=>`
        <button class="animal-card" data-action="selectAnimalHome" data-id="${a.id}">
          <span class="ic">${a.ic}</span>
          <span class="en">${a.en}</span>
          <span class="ta">${a.ta}</span>
        </button>`).join('')}
    </div>

    <div class="tile-grid">
      <button class="tile accent-gold" data-nav="scan">
        <span class="ic">📷</span>
        ${bi('Photo Disease Scan','படம் மூலம் நோய் பரிசோதனை')}
      </button>
      <button class="tile accent-sky" data-nav="voiceAI">
        <span class="ic">🎤</span>
        ${bi('Voice AI','குரல் AI')}
      </button>
      <button class="tile" data-nav="firstAidLibrary">
        <span class="ic">🩹</span>
        ${bi('First Aid','முதலுதவி')}
      </button>
      <button class="tile" data-nav="vaccination">
        <span class="ic">💉</span>
        ${bi('Vaccination','தடுப்பூசி')}
      </button>
      <button class="tile" data-nav="feed">
        <span class="ic">🥬</span>
        ${bi('Feed Management','தீவன மேலாண்மை')}
      </button>
      <button class="tile" data-nav="records">
        <span class="ic">📋</span>
        ${bi('Animal Records','விலங்கு பதிவுகள்')}
      </button>
      <button class="tile" data-nav="reminders">
        <span class="ic">🔔</span>
        ${bi('Reminders','நினைவூட்டல்கள்')}
      </button>
      <button class="tile accent-barn" data-nav="vetFinder">
        <span class="ic">🏥</span>
        ${bi('Nearby Veterinarian','அருகிலுள்ள கால்நடை மருத்துவர்')}
      </button>
      <button class="tile wide accent-barn" data-nav="emergency">
        <span class="ic">🚨</span>
        ${bi('EMERGENCY VET HELP','அவசர கால்நடை உதவி')}
      </button>
    </div>
  </div>
  ${bottomNav('home')}`;
}
