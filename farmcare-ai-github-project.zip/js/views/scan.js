/* FarmCare AI — Photo + voice disease scan and result screens */
"use strict";


function renderScan(){
  const s = state.scan;
  return `
  <div class="screen">
    ${topBar('Disease Scan','நோய் பரிசோதனை')}
    <div class="section-title">${bi('Select Animal','விலங்கை தேர்ந்தெடுக்கவும்')}</div>
    ${renderAnimalTypePicker(s.animalType)}

    <div class="card">
      <div class="section-title">${bi('Photo','புகைப்படம்')}</div>
      ${s.photoData ? `<img class="photo-preview" src="${s.photoData}">` : ''}
      <label class="photo-drop" for="photoInput">
        📷 ${s.photoData ? bi('Change Photo','புகைப்படத்தை மாற்று') : bi('Take / Upload Photo','புகைப்படம் எடு / பதிவேற்று')}
      </label>
      <input type="file" id="photoInput" accept="image/*" capture="environment" style="display:none;">
    </div>

    <div class="card">
      <div class="section-title">${bi('Symptoms','அறிகுறிகள்')}</div>
      <div class="row" style="margin-bottom:10px;">
        <button class="btn btn-ghost btn-sm" id="micScanBtn">🎤 ${bi('Speak','பேசு','1')}</button>
      </div>
      <textarea id="symptomsText" placeholder="e.g. Fever, not eating / காய்ச்சல், சாப்பிடவில்லை">${s.symptomsText||''}</textarea>
    </div>

    <button class="btn btn-primary" data-action="runAnalysis">${bi('Analyze','பரிசோதி','1')}</button>
  </div>
  ${bottomNav('home')}`;
}


function renderScanResult(){
  const r = state.scan.result;
  if(!r) return renderScan();
  const am = animalMeta(r.animal);
  return `
  <div class="screen">
    ${topBar('Analysis Result','பரிசோதனை முடிவு','scan')}

    <div class="card">
      <div class="section-title">${am.ic} ${bi('Animal: '+am.en, am.ta)}</div>
      ${riskChip(r.risk)}
    </div>

    <div class="card">
      <div class="section-title">🔍 ${bi('Visible Signs','தெரியும் அறிகுறிகள்')}</div>
      <p style="font-size:13.5px;margin:0;">${r.visible.en}</p>
      <p style="font-size:12.5px;color:var(--ink-soft);margin:6px 0 0 0;">${r.visible.ta}</p>
    </div>

    <div class="card">
      <div class="section-title">📝 ${bi('Reported Symptoms','தெரிவிக்கப்பட்ட அறிகுறிகள்')}</div>
      <ul class="bullets">
        ${r.reported.map(x=>`<li>${x.en}<div class="small-muted">${x.ta}</div></li>`).join('')}
      </ul>
    </div>

    <div class="card">
      <div class="section-title">🦠 ${bi('Possible Health Problem','சாத்தியமான உடல்நல பிரச்சனை')}</div>
      <div class="small-muted" style="margin-bottom:6px;">${bi('Not a confirmed diagnosis','இது உறுதியான நோய் கண்டறிதல் அல்ல')}</div>
      <ul class="bullets">
        ${r.causes.en.map((c,i)=>`<li>${c}<div class="small-muted">${r.causes.ta[i]||''}</div></li>`).join('')}
      </ul>
    </div>

    <button class="btn btn-primary" data-nav="firstAid">🩹 ${bi('View First Aid','முதலுதவி பார்க்க','1')}</button>
    <div style="height:10px;"></div>
    <button class="btn btn-ghost" data-nav="vetFinder">🏥 ${bi('Find Veterinarian','மருத்துவரை தேடு','1')}</button>
  </div>
  ${bottomNav('home')}`;
}
