/* FarmCare AI — Nearby veterinarian, live location sharing and emergency help */
"use strict";


function renderVetFinder(){
  const vets = demoVets();
  return `
  <div class="screen">
    ${topBar('Nearby Veterinarian','அருகிலுள்ள கால்நடை மருத்துவர்')}
    <button class="btn btn-primary" id="locateBtn" style="margin-bottom:14px;">📍 ${bi('Use My Location','எனது இருப்பிடத்தை பயன்படுத்து','1')}</button>
    <div id="locateStatus" class="small-muted" style="margin-bottom:10px;"></div>
    <div class="demo-box">${bi('Sample directory shown below — connect a verified maps/veterinary-directory service for real, up-to-date clinics and phone numbers in your area.', 'கீழே காட்டப்பட்டவை மாதிரி தகவல் — உண்மையான, துல்லியமான கிளினிக் மற்றும் தொலைபேசி எண்களுக்கு சரிபார்க்கப்பட்ட வரைபட/கால்நடை சேவை இணைப்பு தேவை.')}</div>

    ${vets.map(v=>`
      <div class="card">
        <div style="font-weight:800;margin-bottom:2px;">${v.name}</div>
        <div class="small-muted" style="margin-bottom:10px;">📏 ${v.distanceKm} km away</div>
        <div class="row">
          <a class="btn btn-primary btn-sm" href="tel:${v.phone}">📞 ${bi('Call','அழை','1')}</a>
          <a class="btn btn-ghost btn-sm" target="_blank" href="https://www.google.com/maps/search/veterinary+clinic">🗺️ ${bi('Directions','வழி','1')}</a>
        </div>
        <div style="height:8px;"></div>
        <button class="btn btn-gold btn-sm" data-action="shareLoc" data-vet="${v.name}">📍 ${bi('Share Location','இருப்பிடத்தை பகிர்','1')}</button>
      </div>`).join('')}
  </div>
  ${bottomNav('home')}`;
}


function renderLiveLocation(){
  const ls = state.liveShare;
  return `
  <div class="screen">
    ${topBar('Live Location Sharing','நேரடி இருப்பிட பகிர்வு','vetFinder')}
    ${!ls.active ? `
      <div class="card">
        <div class="section-title">${bi('Share With Veterinarian','மருத்துவருடன் பகிர')}</div>
        <p class="small-muted">${bi('This will request your GPS location and share a temporary live link. You can stop sharing at any time.', 'இது உங்கள் GPS இருப்பிடத்தை கோரி, ஒரு தற்காலிக நேரடி இணைப்பை பகிரும். எப்போது வேண்டுமானாலும் பகிர்வதை நிறுத்தலாம்.')}</p>
        <button class="btn btn-primary" id="startShareBtn">📍 ${bi('Start Sharing','பகிர்வை தொடங்கு','1')}</button>
      </div>
    ` : `
      <div class="card">
        <div class="section-title">✅ ${bi('Sharing Live Location','நேரடி இருப்பிடம் பகிரப்படுகிறது')}</div>
        <p class="small-muted">${bi('With: ', 'உடன்: ')} ${ls.vetName||'Veterinarian'}</p>
        <div class="divider"></div>
        <div id="liveLocData" class="small-muted">${bi('Getting location…','இருப்பிடம் பெறப்படுகிறது…')}</div>
        <div class="divider"></div>
        <button class="btn btn-emg" id="stopShareBtn">${bi('Stop Sharing','பகிர்வை நிறுத்து','1')}</button>
      </div>
    `}
    <div class="info-box">${bi('Your location is never shared without your permission and only for the purpose you choose here.', 'உங்கள் அனுமதி இல்லாமல் இருப்பிடம் ஒருபோதும் பகிரப்படாது; நீங்கள் தேர்ந்தெடுத்த நோக்கத்திற்கு மட்டுமே பயன்படுத்தப்படும்.')}</div>
  </div>
  ${bottomNav('home')}`;
}


function renderEmergency(){
  const signs = [
    {en:'Animal cannot stand', ta:'விலங்கு நிற்க முடியவில்லை'},
    {en:'Severe breathing difficulty', ta:'கடுமையான மூச்சு சிரமம்'},
    {en:'Severe bleeding', ta:'கடுமையான ரத்தப்போக்கு'},
    {en:'Convulsions', ta:'வலிப்பு'},
    {en:'Severe dehydration', ta:'கடுமையான நீர்ச்சத்து குறைவு'},
    {en:'Sudden collapse', ta:'திடீர் சரிவு'},
    {en:'Rapid deterioration', ta:'விரைவான உடல்நிலை மோசமடைதல்'},
  ];
  return `
  <div class="screen">
    ${topBar('Emergency Vet Help','அவசர கால்நடை உதவி')}
    <div class="card" style="background:var(--emg);color:#fff;">
      <div style="font-size:20px;font-weight:800;">🚨 ${bi('If your animal shows any of these signs, seek immediate professional veterinary help.', 'இந்த அறிகுறிகள் இருந்தால், உடனடியாக தொழில்முறை கால்நடை மருத்துவ உதவியை நாடுங்கள்.')}</div>
    </div>
    <div class="card">
      <ul class="bullets">
        ${signs.map(s=>`<li>${s.en}<div class="small-muted">${s.ta}</div></li>`).join('')}
      </ul>
    </div>
    <div class="stack">
      <button class="btn btn-emg" id="emgLocateBtn">📍 ${bi('Get Current Location','தற்போதைய இருப்பிடம்','1')}</button>
      <button class="btn btn-primary" data-nav="vetFinder">🏥 ${bi('Find Nearest Vet Service','அருகிலுள்ள சேவையை கண்டுபிடி','1')}</button>
      <button class="btn btn-gold" data-nav="liveLocation">📍 ${bi('Share Live Location','நேரடி இருப்பிடம் பகிர்','1')}</button>
    </div>
    <div id="emgStatus" class="small-muted" style="margin-top:10px;"></div>
  </div>
  ${bottomNav('home')}`;
}
