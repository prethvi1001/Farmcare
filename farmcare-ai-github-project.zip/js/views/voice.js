/* FarmCare AI — Voice AI screen */
"use strict";


/* ---- Voice AI ---- */
function renderVoiceAI(){
  const v = state.voice;
  return `
  <div class="screen">
    ${topBar('Voice AI','குரல் AI')}
    <div class="center">
      <button class="mic-btn ${v.listening?'listening':''}" id="voiceMicBtn">🎤</button>
      <div>${bi('Speak to FarmCare AI','FarmCare AI-யிடம் பேசுங்கள்')}</div>
    </div>
    ${v.transcript ? `<div class="card" style="margin-top:18px;"><div class="section-title">${bi('You said','நீங்கள் சொன்னது')}</div><p style="margin:0;">${v.transcript}</p></div>` : ''}
    ${v.reply ? `
      <div class="card">
        <div class="section-title">🤖 ${bi('FarmCare AI','FarmCare AI')}</div>
        <p style="font-size:14px;margin:0 0 6px 0;">${v.reply.en}</p>
        <p style="font-size:13px;color:var(--ink-soft);margin:0;">${v.reply.ta}</p>
        <button class="btn btn-ghost btn-sm" style="margin-top:10px;" id="listenBtn">🔊 ${bi('Listen','கேட்க','1')}</button>
      </div>
    ` : ''}
    <div class="card">
      <textarea id="voiceTypeInput" placeholder="Or type your question here / அல்லது இங்கே தட்டச்சு செய்யவும்"></textarea>
      <button class="btn btn-primary btn-sm" style="margin-top:8px;" id="voiceSendBtn">${bi('Ask','கேள்','1')}</button>
    </div>
  </div>
  ${bottomNav('voiceAI')}`;
}
