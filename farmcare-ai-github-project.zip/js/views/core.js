/* FarmCare AI — Router (render), top bar, bottom navigation and shared UI pieces */
"use strict";


/* ---------------- Renderers ---------------- */
function render(){
  const app = document.getElementById('app');
  let html = '';
  switch(state.page){
    case 'splash': html = renderSplash(); break;
    case 'login': html = renderLogin(); break;
    case 'home': html = renderHome(); break;
    case 'scan': html = renderScan(); break;
    case 'scanResult': html = renderScanResult(); break;
    case 'firstAid': html = renderFirstAid(); break;
    case 'firstAidLibrary': html = renderFirstAidLibrary(); break;
    case 'medicine': html = renderMedicine(); break;
    case 'vetFinder': html = renderVetFinder(); break;
    case 'liveLocation': html = renderLiveLocation(); break;
    case 'emergency': html = renderEmergency(); break;
    case 'vaccination': html = renderVaccinationHub(); break;
    case 'vaccinationAnimal': html = renderVaccinationAnimal(); break;
    case 'vaccinationGuide': html = renderVaccinationGuide(); break;
    case 'records': html = renderRecordsList(); break;
    case 'recordDetail': html = renderRecordDetail(); break;
    case 'recordAdd': html = renderRecordAdd(); break;
    case 'feed': html = renderFeed(); break;
    case 'reminders': html = renderReminders(); break;
    case 'voiceAI': html = renderVoiceAI(); break;
    case 'settings': html = renderSettings(); break;
    default: html = renderHome();
  }
  app.innerHTML = html;
  app.className = state.lang === 'en' ? 'lang-en-only' : (state.lang === 'ta' ? 'lang-ta-only' : '');
  attachHandlers();
}


function topBar(en, ta, back){
  return `<div class="topbar">
    ${back!==false?`<button class="back" data-nav="${typeof back==='string'?back:'home'}">←</button>`:''}
    <h1>${en}<span class="ta">${ta}</span></h1>
  </div>`;
}


function bottomNav(active){
  const items = [
    {id:'home', ic:'🏠', en:'Home', ta:'முகப்பு'},
    {id:'records', ic:'🐄', en:'Animals', ta:'விலங்குகள்'},
    {id:'voiceAI', ic:'🤖', en:'AI', ta:'AI உதவி'},
    {id:'vaccination', ic:'📋', en:'Records', ta:'பதிவுகள்'},
    {id:'settings', ic:'⚙️', en:'Settings', ta:'அமைப்புகள்'},
  ];
  return `<div class="bottom-nav">
    ${items.map(it=>`
      <button class="nav-btn ${active===it.id?'active':''}" data-nav="${it.id}">
        <span class="ic">${it.ic}</span>
        <span class="lab"><span class="en">${it.en}</span><span class="ta">${it.ta}</span></span>
      </button>`).join('')}
  </div>`;
}


function renderAnimalTypePicker(selected, action){
  action = action || 'setScanAnimal';
  return `<div class="animal-grid">
    ${ANIMAL_TYPES.map(a=>`
      <button class="animal-card ${selected===a.id?'selected':''}" data-action="${action}" data-id="${a.id}">
        <span class="ic">${a.ic}</span><span class="en">${a.en}</span><span class="ta">${a.ta}</span>
      </button>`).join('')}
  </div>`;
}


function riskChip(risk){
  const labels = {low:{en:'Low',ta:'குறைவு',ic:'🟢'}, moderate:{en:'Moderate',ta:'மிதமான',ic:'🟡'}, high:{en:'High',ta:'அதிக',ic:'🟠'}, emergency:{en:'Emergency',ta:'அவசரம்',ic:'🔴'}};
  const l = labels[risk];
  return `<span class="chip ${risk}">${l.ic} ${l.en} / ${l.ta}</span>`;
}


function emptyState(en, ta){
  return `<div class="card center" style="color:var(--ink-soft);">
    <div style="font-size:30px;margin-bottom:6px;">🗒️</div>
    <div>${en}</div><div class="small-muted">${ta}</div>
  </div>`;
}


function animalListItem(a, extra){
  const am = animalMeta(a.type);
  const vaccs = a.vaccinations||[];
  const nextUp = vaccs.slice().sort((x,y)=> new Date(x.nextDue)-new Date(y.nextDue))[0];
  let badge = '';
  if(nextUp){
    const st = vaccStatus(nextUp.nextDue);
    badge = `<span class="status-badge ${st}">${st==='overdue'?'❌ Overdue':st==='due'?'⏳ Due soon':'✅ Scheduled'}</span>`;
  }
  return `<button class="list-item" data-action="goVaccAnimal" data-id="${a.id}">
    <div style="display:flex;align-items:center;gap:10px;">
      ${a.photoData?`<img class="avatar-photo" src="${a.photoData}">`:`<div class="avatar-photo" style="display:flex;align-items:center;justify-content:center;font-size:26px;">${am.ic}</div>`}
      <div>
        <div style="font-weight:800;">${a.name||am.en} <span class="small-muted">(${am.en})</span></div>
        <div class="meta">${bi(a.breed||'—', '', '1')}</div>
      </div>
    </div>
    ${badge}
  </button>`;
}
