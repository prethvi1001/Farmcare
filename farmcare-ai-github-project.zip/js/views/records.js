/* FarmCare AI — Livestock records: list, add and detail screens */
"use strict";


/* ---- Records ---- */
function renderRecordsList(){
  return `
  <div class="screen">
    ${topBar('Animal Records','விலங்கு பதிவுகள்')}
    <button class="btn btn-primary" data-nav="recordAdd" style="margin-bottom:14px;">➕ ${bi('Add Animal','விலங்கை சேர்','1')}</button>
    ${state.animals.length===0 ? emptyState('No animals added yet. Tap "Add Animal" to get started.', 'இன்னும் விலங்கு சேர்க்கப்படவில்லை. தொடங்க "விலங்கை சேர்" அழுத்தவும்.') :
      state.animals.map(a=>`
        <button class="list-item" data-action="goRecordDetail" data-id="${a.id}">
          <div style="display:flex;align-items:center;gap:10px;">
            ${a.photoData?`<img class="avatar-photo" src="${a.photoData}">`:`<div class="avatar-photo" style="display:flex;align-items:center;justify-content:center;font-size:26px;">${animalMeta(a.type).ic}</div>`}
            <div>
              <div style="font-weight:800;">${a.name||animalMeta(a.type).en}</div>
              <div class="meta">${animalMeta(a.type).en} · ${a.breed||'—'} · ${a.sex||'—'}</div>
            </div>
          </div>
          <span>›</span>
        </button>`).join('')}
  </div>
  ${bottomNav('records')}`;
}


function renderRecordAdd(){
  return `
  <div class="screen">
    ${topBar('Add Animal','விலங்கை சேர்','records')}
    <div class="card">
      <div class="section-title">${bi('Photo','புகைப்படம்')}</div>
      <div id="newPhotoPreviewWrap"></div>
      <label class="photo-drop" for="newAnimalPhoto">📷 ${bi('Add Photo','புகைப்படம் சேர்','1')}</label>
      <input type="file" id="newAnimalPhoto" accept="image/*" capture="environment" style="display:none;">
    </div>
    <div class="card">
      <div class="section-title">${bi('Type','வகை')}</div>
      ${renderAnimalTypePicker(state.scan.animalType)}
      <div class="stack">
        <input type="text" id="raName" placeholder="Name / ID · பெயர் / அடையாள எண்">
        <div class="row">
          <input type="text" id="raBreed" placeholder="Breed / இனம்">
          <select id="raSex"><option value="">Sex / பாலினம்</option><option value="Male">Male / ஆண்</option><option value="Female">Female / பெண்</option></select>
        </div>
        <div class="row">
          <input type="number" id="raAge" placeholder="Age (months) / வயது">
          <input type="number" id="raWeight" placeholder="Weight (kg) / எடை">
        </div>
        <textarea id="raNotes" placeholder="Notes: health, feed, breeding etc. / குறிப்புகள்"></textarea>
      </div>
    </div>
    <button class="btn btn-primary" data-action="saveNewAnimal">${bi('Save Animal','விலங்கை சேமி','1')}</button>
  </div>
  ${bottomNav('records')}`;
}


function renderRecordDetail(){
  const a = getAnimal(state.selectedAnimalId);
  if(!a) return renderRecordsList();
  const am = animalMeta(a.type);
  return `
  <div class="screen">
    ${topBar(a.name||am.en, am.ta, 'records')}
    <div class="card center">
      ${a.photoData?`<img class="photo-preview" src="${a.photoData}">`:`<div style="font-size:50px;">${am.ic}</div>`}
      <div style="font-weight:800;font-size:18px;margin-top:6px;">${a.name||am.en}</div>
      <div class="small-muted">${am.en} / ${am.ta}</div>
    </div>
    <div class="card">
      <div class="section-title">${bi('Profile','விவரம்')}</div>
      <div class="row" style="margin-bottom:8px;"><span class="small-muted grow">Breed / இனம்</span><b>${a.breed||'—'}</b></div>
      <div class="row" style="margin-bottom:8px;"><span class="small-muted grow">Sex / பாலினம்</span><b>${a.sex||'—'}</b></div>
      <div class="row" style="margin-bottom:8px;"><span class="small-muted grow">Age / வயது</span><b>${a.age?a.age+' mo':'—'}</b></div>
      <div class="row"><span class="small-muted grow">Weight / எடை</span><b>${a.weight?a.weight+' kg':'—'}</b></div>
    </div>
    ${a.notes?`<div class="card"><div class="section-title">${bi('Notes','குறிப்புகள்')}</div><p style="font-size:14px;margin:0;">${a.notes}</p></div>`:''}

    <div class="card">
      <div class="section-title">💉 ${bi('Vaccination History','தடுப்பூசி வரலாறு')}</div>
      ${(a.vaccinations&&a.vaccinations.length) ? a.vaccinations.map(v=>`<div class="small-muted" style="margin-bottom:4px;">• ${v.name} — ${bi('next','அடுத்தது','1')} ${fmtDate(v.nextDue)}</div>`).join('') : `<div class="small-muted">${bi('No records yet','பதிவுகள் இல்லை')}</div>`}
      <button class="link-btn" data-action="goVaccAnimal" data-id="${a.id}">${bi('Manage vaccinations','தடுப்பூசி நிர்வகி')} →</button>
    </div>

    <div class="row" style="margin-top:4px;">
      <button class="btn btn-ghost btn-sm" data-nav="scan">🩹 ${bi('New Health Check','புதிய பரிசோதனை','1')}</button>
      <button class="btn btn-emg btn-sm" data-action="deleteAnimalConfirm" data-id="${a.id}">🗑️ ${bi('Delete','நீக்கு','1')}</button>
    </div>
  </div>
  ${bottomNav('records')}`;
}
